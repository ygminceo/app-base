export interface OtpTemplateModel {
  otp: string;
}
